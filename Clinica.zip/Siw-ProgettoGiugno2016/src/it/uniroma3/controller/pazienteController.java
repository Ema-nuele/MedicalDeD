package it.uniroma3.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.uniroma3.model.Paziente;

/**
 * Servlet implementation class pazienteController
 */
@WebServlet("/controllerPaziente")
public class pazienteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pazienteController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String nome = request.getParameter("nome");
		String cognome = request.getParameter("cognome");
		String indirizzo = request.getParameter("indirizzo");
		String email = request.getParameter("email");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String passwordR = request.getParameter("passwordR"); // password per la verifica
		
		boolean ciSonoErrori = false;
		String nextPage = null;
		if (nome.equals("")) {
			ciSonoErrori = true;
			request.setAttribute("nomeError", "Nome Obbligatorio");
		}
		if (cognome.equals("")) {
			ciSonoErrori = true;
			request.setAttribute("cognomeError", "Cognome Obbligatorio");
		}
		if (indirizzo.equals("")) {
			ciSonoErrori = true;
			request.setAttribute("indirizzoError", "Indirizzo Obbligatorio");
		}
		if(email.equals("")){
			ciSonoErrori= true;
			request.setAttribute("emailError", "Email Obbligatoria");
			
		}
		if(username.equals("")){
			ciSonoErrori= true;
			request.setAttribute("usernameError", "Username Obbligatorio");
			
		}
		if (password.equals("")) {
			request.setAttribute("passwordError", "Inserisci una password");
			ciSonoErrori = true;

			/* Controllo lunghezza minima password */
		} else if (password.length() < 5) {
			ciSonoErrori = true;
			request.setAttribute("passwordError",
					"La password deve contenere almeno 5 caratteri");
		}

		/* Controllo Ripeti Password */
		else if (!password.equals(passwordR)) {
			ciSonoErrori = true;
			request.setAttribute("passwordRError",
					"Le password non coincidono");
		}

		if (ciSonoErrori) {
			nextPage = "/registrazionePaziente.jsp";
		} else { // Tutti i dati sono corretti
			Paziente paziente = new Paziente();
			paziente.setNome(nome);
			paziente.setCognome(cognome);
			paziente.setIndirizzo(indirizzo);
			paziente.setEmail(email);
			paziente.setUsername(username);
			paziente.setPassword(password);
			request.setAttribute("paziente", paziente);
			nextPage = "/confermaRegistrazionePaziente.jsp";
		}
		ServletContext servletContext = getServletContext();
		RequestDispatcher rd = servletContext.getRequestDispatcher(nextPage);
		rd.forward(request, response);
	}
	

	

}
