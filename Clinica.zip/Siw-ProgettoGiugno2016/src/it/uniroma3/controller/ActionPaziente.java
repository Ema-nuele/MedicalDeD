package it.uniroma3.controller;

import it.uniroma3.model.Paziente;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;
import it.uniroma3.model.Facade;

public class ActionPaziente
{
	public String Execute(HttpServletRequest request, EntityManager em)
	{
		Paziente paziente=new Paziente();
		Facade facade=new Facade();
		
		paziente.setNome(request.getParameter("nome"));
		paziente.setCognome(request.getParameter("cognome"));
		paziente.setUsername((request.getParameter("username")));
		paziente.setEmail((request.getParameter("email")));
		paziente.setIndirizzo((request.getParameter("indirizzo")));
		paziente.setPassword((request.getParameter("password")));
		
		facade.inserisciPaziente(paziente,em);
		request.setAttribute("paziente",paziente);
		return "/confermaRegistrazionePaziente.jsp";
	}

}
