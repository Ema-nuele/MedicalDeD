package it.uniroma3.controller;

import javax.servlet.http.HttpServletRequest;

import it.uniroma3.model.TipologiaEsame;

public class ActionTipologia {
	
	public String Execute(HttpServletRequest request) {
		TipologiaEsame tipologia = new TipologiaEsame();
		
		tipologia.setNome(request.getParameter("nome"));
		tipologia.setDescrizione(request.getParameter("descrizione"));
		tipologia.setCosto(Long.valueOf(request.getParameter("costo")).longValue());
		

		/*
		 * manca la gestione dei prerequisiti 
		 * e degli indicatori dei risultati
		 */
		
		request.setAttribute("tipologia", tipologia);
		return "/confermaTipologiaEsame.jsp";
	}

}
