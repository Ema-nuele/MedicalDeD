package it.uniroma3.helper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//CONTROLLO DATI IMMESSI
public class HelperTipologia {
		public boolean Validate(HttpServletRequest request, HttpServletResponse response)
		{
			boolean corretto = true;
			String nome,descrizione;
			String nomeError,descrizioneError,costoError;
			String costo = request.getParameter("costo");
			//String[] indicatori;
			//String [] prerequisiti;
			nome = request.getParameter("nome");
			descrizione = request.getParameter("descrizione");
			
//			prerequisiti = request.getParameterValues("prerequisiti");
//			indicatori = request.getParameterValues("indicatori");
			
			if(nome.equals(""))
			{
				corretto = false;
				nomeError ="Nome: Campo Obbligatorio";
				request.setAttribute("nomeError", nomeError);
			}
			if(descrizione.equals(""))
			{
				corretto = false;
				descrizioneError ="Descrizione: Campo Obbligatorio";
				request.setAttribute("descrizioneError", descrizioneError);
			}
			
			try {
				double c = Double.parseDouble(costo);
				if(costo == null || costo.isEmpty() || c < 0) {
					corretto = false;
					costoError ="Costo: Campo Obbligatorio";
					request.setAttribute("costoError", costoError);
				}
			}catch (NumberFormatException e) {
				corretto = false;
				costoError = "Inserisci un prezzo valido";
				request.setAttribute("costoError", costoError);
			}
			
			
//			if(prerequisiti.equals("")) {
//			
//				corretto = false;
//				prerequisitiError ="Prerequisito: Campo Obbligatorio";
//				request.setAttribute("prerequisitiError", prerequisitiError);
//			}
//			if(indicatori.equals(""))
//			{
//				corretto = false;
//				indicatoriError ="Indicatore: Campo Obbligatorio";
//				request.setAttribute("indicatoriError", indicatoriError);
//			}
			
			
			return corretto;
			
		
		}
			
					}

