package it.uniroma3.controller;
import it.uniroma3.model.TipologiaEsame;

import javax.servlet.http.HttpServletRequest;

public class ActionTipologia {
	
	public TipologiaEsame Execute(HttpServletRequest request)
	{
		TipologiaEsame tipo=new TipologiaEsame();
		
		
		tipo.setNomeTipologia(request.getParameter("nome"));
		tipo.setDescrizione(request.getParameter("descrizione"));
		tipo.setCosto(Integer.parseInt(request.getParameter("costo")));
		
		return tipo;
	}

}

