package it.uniroma3.controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelperMedico {
	public boolean Validate(HttpServletRequest request, HttpServletResponse response)
	{
		boolean corretto = true;
		String nome,cognome,nomeError,cognomeError;
		
		nome = request.getParameter("nome");
		cognome = request.getParameter("cognome");
		
		if(nome.equals(""))
		{
			corretto = false;
			nomeError ="Nome: Campo Obbligatorio";
			request.setAttribute("nomeError", nomeError);
		}
		
		if(cognome.equals(""))
		{
			corretto = false;
			cognomeError = "Cognome: Campo Obbligatorio";
			request.setAttribute(cognomeError, "cognomeError");
		}
		
		return corretto;
	}

}
