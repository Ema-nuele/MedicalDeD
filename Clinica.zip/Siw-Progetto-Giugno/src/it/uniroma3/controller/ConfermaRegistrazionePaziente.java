package it.uniroma3.controller;

import javax.annotation.ManagedBean;
import javax.ejb.EJB;
import javax.servlet.http.HttpServlet;

import it.uniroma3.model.Facade;
import it.uniroma3.model.Paziente;


@ManagedBean

public class ConfermaRegistrazionePaziente extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB(beanName="Facade")
	private Facade facade;
	
	public void salvaPaziente(Paziente p)
	{
		facade.getEM().persist(p);    // come prendo il paziente della sessione?
		
	}
	
    
	
	/*
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		HttpSession session = request.getSession();
        this.facade.inserisciPaziente((Paziente)session.getAttribute("paziente"));  //recupero oggetti della sessione
        String nextPage="/registrazionePazienteAvvenuta.jsp";
		nextPage=response.encodeURL(nextPage);
		ServletContext servletContext=getServletContext();
		RequestDispatcher rd  = servletContext.getRequestDispatcher(nextPage);
		rd.forward(request, response);
		
	}*/

}
