package it.uniroma3.controller;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.uniroma3.model.Facade;

/**
 * Servlet implementation class ControllerRequisiti
 */
@WebServlet("/controllerPrerequisito")
public class ControllerPrerequisiti extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@EJB(beanName="Facade")
	private Facade facade;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerPrerequisiti() {
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	  
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println(request.getParameter("tipologia"));
		
		
	}

}
