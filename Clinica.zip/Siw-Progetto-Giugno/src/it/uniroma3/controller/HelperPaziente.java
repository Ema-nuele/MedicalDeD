package it.uniroma3.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// CONTROLLO SUI DATI IMMESSI 
public class HelperPaziente 
{
	public boolean Validate(HttpServletRequest request, HttpServletResponse response)
	{
		boolean corretto=true; 
		String nome,cognome,username,password,nomeError,cognomeError,userError,passError;
		nome=request.getParameter("nome");
		cognome=request.getParameter("cognome");
		username=request.getParameter("username");
		password=request.getParameter("password");
		
				
		if(nome.equals(""))
			{
			corretto=false;
			nomeError="Nome: Campo Obbligatorio";
			request.setAttribute("nomeError",nomeError);
			}
		
		if(cognome.equals(""))
		{
		corretto=false;
		cognomeError="Cognome: Campo Obbligatorio";
		request.setAttribute("cognomeError",cognomeError);
		}
		
		if(username.equals(""))
		{
		corretto=false;
		userError="Username: Campo Obbligatorio";
		request.setAttribute("userError",userError);
		}
		
		if(password.equals(""))
		{
		corretto=false;
		passError="Password: Campo Obbligatorio";
		request.setAttribute("passError",passError);
		}
		
        
	
return corretto;	
	}

}
