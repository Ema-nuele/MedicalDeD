package it.uniroma3.controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// CONTROLLO SUI DATI IMMESSI 
public class HelperPaziente 
{
	public boolean Validate(HttpServletRequest request, HttpServletResponse response)
	{
		boolean corretto=true; 
		String nome,cognome,indirizzo,indError,nomeError,cognomeError;
		
		
		nome=request.getParameter("nome");
		cognome=request.getParameter("cognome");
		
		indirizzo=request.getParameter("indirizzo");
		
		if(indirizzo.equals(""))
		{
		corretto=false;
		indError="Indirizzo: Campo Obbligatorio";
		request.setAttribute("indError",indError);
		}
	
		
	
				
		if(nome.equals(""))
			{
			corretto=false;
			nomeError="Nome: Campo Obbligatorio";
			request.setAttribute("nomeError",nomeError);
			}
		
		if(cognome.equals(""))
		{
		corretto=false;
		cognomeError="Cognome: Campo Obbligatorio";
		request.setAttribute("cognomeError",cognomeError);
		}
		
		
        
	
return corretto;	
	}

}
