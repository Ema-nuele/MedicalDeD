package it.uniroma3.controller;


import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;



import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

import java.util.Calendar;
import java.text.SimpleDateFormat;

import it.uniroma3.model.Facade;
import it.uniroma3.model.Esame;
import it.uniroma3.model.Paziente;
import it.uniroma3.model.TipologiaEsame;
import it.uniroma3.model.Medico;

public class ActionEsame {
	
	public String Execute(HttpServletRequest request, Facade facade) throws java.text.ParseException
	{
		Esame esame =new Esame();
		EntityManager em= facade.getEM();
		SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyyy");  // formato data da convertire
		Calendar c = Calendar.getInstance();
		
		Query query=em.createQuery("SELECT p From Paziente p WHERE p.id= : id" );
		query.setParameter("id", Long.valueOf(request.getParameter("paziente")).longValue());
		esame.setPaziente((Paziente)query.getSingleResult());
		
		query=em.createQuery("SELECT t From TipologiaEsame t WHERE t.nomeTipologia= : id" );
		query.setParameter("id",request.getParameter("tipologia"));
		esame.setTipologia((TipologiaEsame)query.getSingleResult());
		
		
		query=em.createQuery("SELECT m From Medico m WHERE m.id= : id" );
		query.setParameter("id", Long.valueOf(request.getParameter("medico")).longValue());
		esame.setMedico((Medico)query.getSingleResult());
		
		
		try{
		String data=request.getParameter("dataEsame");
		esame.setDataEsame(format.parse(data)); }
		catch(ParseException e)
		{ e.printStackTrace();}
		
		esame.setDataCreazione(c.getTime());   //prende data istantanea
		
		facade.inserisciEsame(esame);   // va fatto quando confermato
		request.setAttribute("esame",esame);
     	return "/confermaEsame.jsp";


	}

}
