package it.uniroma3.controller;

import it.uniroma3.model.Paziente;

import javax.servlet.http.HttpServletRequest;


public class ActionPaziente
{
	public Paziente Execute(HttpServletRequest request)
	{
		Paziente paziente=new Paziente();
		
		
		paziente.setNome(request.getParameter("nome"));
		paziente.setCognome(request.getParameter("cognome"));
		
		paziente.setIndirizzo((request.getParameter("indirizzo")));
		
		return paziente;
	}

}
