package it.uniroma3.controller;

import it.uniroma3.model.Paziente;

import javax.servlet.http.HttpServletRequest;


public class ActionPaziente
{
	public String Execute(HttpServletRequest request)
	{
		Paziente paziente=new Paziente();
		
		
		paziente.setNome(request.getParameter("nome"));
		paziente.setCognome(request.getParameter("cognome"));
		paziente.setUsername((request.getParameter("username")));
		paziente.setEmail((request.getParameter("email")));
		paziente.setIndirizzo((request.getParameter("indirizzo")));
		paziente.setPassword((request.getParameter("password")));
		
		
		request.setAttribute("paziente",paziente);
		return "/confermaRegistrazionePaziente.jsp";
	}

}
