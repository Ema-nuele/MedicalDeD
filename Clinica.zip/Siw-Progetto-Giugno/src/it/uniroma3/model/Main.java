package it.uniroma3.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class Main {

// Query funzionante, gli attributi e i nomi delle entit� sono quelli di eclipse, non quelli visti su postgres	

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("clinica-unit");
		EntityManager em = emf.createEntityManager();
	/*	Query query = em.createQuery("SELECT p FROM Paziente p WHERE p.id = :id");
		Long id=1L;
		query.setParameter("id",id);
		System.out.println("Paziente nome: "+ ((Paziente) query.getSingleResult()).getNome());
		*/
		em.close();
		emf.close();
	}

}
