package it.uniroma3.model;

import java.util.List;
import javax.persistence.*;

@Entity

// possibile lista che ritorna tutti gli esami
//List<TipologiaEsame> esami= em.createNamedQuery("mostraTipologie").getResultList();

public class TipologiaEsame {
	@Id
	private String nomeTipologia;
	@Column(nullable=false)
	private String descrizione;
	@Column(nullable=false)
	private double costoTipologia;
	@OneToMany
	private List<Prerequisito> prerequisiti;
	@OneToMany
	private List<Indicatore> indicatori;
	
	public String getNome() {
		return this.nomeTipologia;
	}
	
	public void setNome(String nome) {
		this.nomeTipologia = nome;
		
	}
	
	public String getDescrizione() {
		return this.descrizione;
		
	}
	
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	
	public double getCosto() {
		return this.costoTipologia;
	}
	
	public void setCosto(int costo) {
		this.costoTipologia = costo;
	}


}
