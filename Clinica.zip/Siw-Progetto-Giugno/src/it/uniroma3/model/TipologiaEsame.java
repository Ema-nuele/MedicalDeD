package it.uniroma3.model;

import java.util.List;
import javax.persistence.*;

@Entity
@NamedQuery(name="mostraTipologie", query="SELECT e.nomeE FROM TipologiaEsame e")

// possibile lista che ritorna tutti gli esami
//List<TipologiaEsame> esami= em.createNamedQuery("mostraTipologie").getResultList();

public class TipologiaEsame {
	@Id
	private String nomeE;
	@Column(nullable=false)
	private String descrizioneE;
	@Column(nullable=false)
	private double costoE;
	@OneToMany
	private List<Prerequisito> prerequisiti;
	@OneToMany
	private List<Indicatore> indicatori;
	
	public String getNome() {
		return this.nomeE;
	}
	
	public void setNome(String nome) {
		this.nomeE = nome;
		
	}
	
	public String getDescrizione() {
		return this.descrizioneE;
		
	}
	
	public void setDescrizione(String descrizione) {
		this.descrizioneE = descrizione;
	}
	
	public double getCosto() {
		return this.costoE;
	}
	
	public void setCosto(int costo) {
		this.costoE = costo;
	}


}
