package it.uniroma3.model;

import java.util.Date;
import java.util.List;
import javax.persistence.*;

@Entity
public class Esame {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@OneToOne
	private Long paziente;
	@OneToOne
	private Long tipologia;
	@Temporal (TemporalType.TIMESTAMP)
    private Date dataCreazione;
	@Column(nullable=false)
	private Date dataEsame;
	@OneToOne
	private Long medico;
	@OneToMany
	private List<Risultato> risultati;
	

	
	public Long getTipologia() {
		return tipologia;
	}

	public void setTipologia(Long tipologia) {
		this.tipologia = tipologia;
	}

	
	public Long getId() {
		return id;
	}
	
	public Long getPaziente() {
		return paziente;
	}
	public void setPaziente(Long paziente) {
		this.paziente = paziente;
	}
	public Date getDataCreazione() {
		return dataCreazione;
	}
	public void setDataCreazione(Date dataCreazione) {
		this.dataCreazione = dataCreazione;
	}
	public Date getDataEsame() {
		return dataEsame;
	}
	public void setDataEsame(Date dataEsame) {
		this.dataEsame = dataEsame;
	}
	public Long getMedico() {
		return medico;
	}
	public void setMedico(Long medico) {
		this.medico = medico;
	}
	public List<Risultato> getRisultati() {
		return risultati;
	}
	public void setRisultati(List<Risultato> risultati) {
		this.risultati = risultati;
	}

}