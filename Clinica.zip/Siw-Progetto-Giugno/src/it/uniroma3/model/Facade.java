package it.uniroma3.model;

import java.util.List;
import java.util.ArrayList;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


@Stateless(name="Facade")
public class Facade {
	
	@PersistenceContext(unitName = "clinica-unit")
    private EntityManager em;
	
	public EntityManager getEM()
	{
		return this.em;
	}
	
	// Inserimenti 
	public void inserisciPaziente(Paziente paziente)
	{
		EntityTransaction tx = em.getTransaction();
        tx.begin();
		em.persist(paziente); 
        tx.commit();
	}
	
	public void inserisciTipologia(TipologiaEsame tipo)
	{
		EntityTransaction tx = em.getTransaction();
        tx.begin();
		em.persist(tipo); 
        tx.commit();
		}
	
	
	
	public void inserisciEsame(Esame e)
	{
		EntityTransaction tx = em.getTransaction();
        tx.begin();
		em.persist(e);
		tx.commit();
	}
	
	// Query
	
	public Amministratore loginAmministratore(Long id,String password)
	{
		Query query = em.createQuery("SELECT a FROM Amministratore a WHERE a.id = :id");
		query.setParameter("id",id);
		if(query.getSingleResult()!=null)
		{            Amministratore a=(Amministratore) query.getSingleResult();
		             if(a.getPassword().equals(password))
		                      return a;
		}            
		return null;
	}
	
	public void logout(HttpServletRequest request)
	{
		HttpSession session=request.getSession();
		session.invalidate();
	}
	
	@SuppressWarnings("unchecked")
	public List<TipologiaEsame> getTipologie()
	{
		Query query = em.createQuery("SELECT t FROM TipologiaEsame t");
		List<TipologiaEsame> lista=new ArrayList<>();
		lista=(List<TipologiaEsame>) query.getResultList();
		return lista ;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Prerequisito> getPrerequisiti()
	{
		Query query = em.createQuery("SELECT t FROM Prerequisito t");
		List<Prerequisito> lista= (List<Prerequisito>) query.getResultList();
		return lista ;
	}
	
	
	
	public void cancellaTipologia(String nome)
	{
		EntityTransaction tx=em.getTransaction();
	    tx.begin();
		Query query = em.createQuery("DELETE t FROM TipologiaEsame t WHERE t.nome=:nome");
		query.setParameter("nome", nome);
		tx.commit();
		
	}
	
	public void cancellaTipologiaRequisito(String nome)
	{
		EntityTransaction tx = em.getTransaction();
        tx.begin();
		Query query = em.createQuery("DELETE t FROM TipologiaEsame_Requisito t WHERE t.nome=:nome");
		query.setParameter("nome", nome);
		tx.commit();
	}
	
	public void cancellaTipologia_Indicatore(String nome)
	{
		EntityTransaction tx=em.getTransaction();
		tx.begin();
		Query query = em.createQuery("DELETE t FROM TipologiaEsame_Indicatore t WHERE t.nome=:nome");
		query.setParameter("nome", nome);
		tx.commit();
		
	}
	
	
	
	//Query UC5
	
	public Medico getMedicoByNome(String nome,String cognome)
	{
		EntityTransaction tx=em.getTransaction();
		tx.begin();
		Query query = em.createQuery("SELECT t FROM Medico t WHERE t.nome=:nome AND t.cognome=:cognome");
		query.setParameter("nome", nome);
		query.setParameter("cognome",cognome);
        Medico m=(Medico)query.getSingleResult();
		tx.commit();
		return m;
	}
	
	@SuppressWarnings("unchecked")
	public List<Esame> getEsamiMedico(Medico m)
	{
		EntityTransaction tx=em.getTransaction();
		tx.begin();
		Query query= em.createQuery("SELECT e FROM Esame e WHERE e.medico = :medico");
		query.setParameter("medico",m);
		List <Esame> esami=new ArrayList<>();
		esami= (List<Esame>) query.getResultList();
		tx.commit();
	    return esami;
	}

}
