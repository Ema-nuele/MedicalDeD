package it.uniroma3.controller;

import java.util.Date;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import it.uniroma3.model.Esame;
import it.uniroma3.model.FacadeEsame;
import it.uniroma3.model.Medico;
import it.uniroma3.model.Paziente;
import it.uniroma3.model.TipologiaEsame;

@ManagedBean(name="controllerEsame")
@SessionScoped

public class ControllerEsame 
{
	private Paziente paziente;
	private TipologiaEsame tipoEsame;
	private Date dataCreazione;
	private Date dataEsame;
	private Medico medico;
	private Esame esame;

	@EJB(beanName="facadeEsame")
	private FacadeEsame facade;

	
	
	public String creaEsame()   // da chiamare in inserisci esame
	{
		dataCreazione=new Date();
		this.esame=new Esame(this.paziente,this.tipoEsame,this.dataCreazione,this.dataEsame,this.medico);
		return "confermaEsame";
	}
	
	public String salvaEsame() // da chiamare in conferma esame
	{
		facade.aggiungi(this.esame);
		return "confermaEsameAvvenuta";
	}
	
	public String annulla()
	{
		this.esame=null;
		return "amministrazione";
	}
	
	
	public Paziente getPaziente() {
		return this.paziente;
	}

	public void setPaziente(Paziente paziente) {
		this.paziente = paziente;
	}

	public TipologiaEsame getTipoEsame() {
		return this.tipoEsame;
	}

	public void setTipoEsame(TipologiaEsame tipoEsame) {
		this.tipoEsame = tipoEsame;
	}

	public Date getDataCreazione() {
		return this.dataCreazione;
	}

	public void setDataCreazione(Date dataCreazione) {
		this.dataCreazione = dataCreazione;
	}

	public Date getDataEsame() {
		return this.dataEsame;
	}

	public void setDataEsame(Date dataEsame) {
		this.dataEsame = dataEsame;
	}

	public Medico getMedico() {
		return this.medico;
	}

	public void setMedico(Medico medico) {
		this.medico = medico;
	}


	public Esame getEsame() {
		return esame;
	}


	public void setEsame(Esame esame) {
		this.esame = esame;
	}

	
	
}
