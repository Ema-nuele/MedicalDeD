package it.uniroma3.controller;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;

import it.uniroma3.model.Amministratore;
import it.uniroma3.model.FacadeAdmin;

@ManagedBean(name="controllerAdmin")
public class ControllerAdmin {
	
	private String nome;
	private String cognome;
	private String email;
	private String username;
	private String indirizzo;
	private String password;
	private Amministratore amministratore;
	
	@EJB(beanName="facadeAdmin")
	private FacadeAdmin facade;
	
	
	public String aggiungi()
	{
		
		amministratore=facade.creaAmministratore(nome,cognome,username,password,email,indirizzo);
		return "login";
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return this.cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getIndirizzo() {
		return this.indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public FacadeAdmin getFacade() {
		return facade;
	}

	public Amministratore getAmministratore() {
		return this.amministratore;
	}

	public void setAmministratore(Amministratore a) {
		this.amministratore = a;
	}

	


}
