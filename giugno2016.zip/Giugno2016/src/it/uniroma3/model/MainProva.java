package it.uniroma3.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class MainProva {
 
	public static void main(String[] args) {
		
		Amministratore a=new Amministratore();
		a.setNome("nome");
		a.setCognome("c");
		a.setEmail("email");
		a.setIndirizzo("ind");
		a.setPassword("pass");
		a.setUsername("chicco");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("clinica-unit");
		EntityManager em = emf.createEntityManager();		
		em.persist(a);
		
		em.close();
		emf.close();
		

	}

}
