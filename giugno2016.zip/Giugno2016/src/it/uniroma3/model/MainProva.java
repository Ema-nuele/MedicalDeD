package it.uniroma3.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import it.uniroma3.controller.ControllerTipologia;

public class MainProva {
 
	public static void main(String[] args) {
		
//		EntityManagerFactory emf = Persistence.createEntityManagerFactory("clinica-unit");
//		EntityManager em = emf.createEntityManager();
	    
		ControllerTipologia ct=new ControllerTipologia();
		
		
	//	em.persist(p);
	//	em.persist(t);
		
	//	t.aggiungiPrerequisito(p);
	//	System.out.println("size :" + t.getPrerequisiti().get(0).getNome());
		
		
//		em.close();
//		emf.close();
		

	}

}
