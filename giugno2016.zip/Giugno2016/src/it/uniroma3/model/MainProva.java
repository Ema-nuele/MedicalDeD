package it.uniroma3.model;

import java.util.Date;

public class MainProva {
 
	public static void main(String[] args) {
		
	//	FacadeAdmin facade=new FacadeAdmin();
	//	Amministratore a=facade.login(1L, "prova");
		
		Date d=new Date();   // data corrente
		
		System.out.println(d);
		

	}

}
