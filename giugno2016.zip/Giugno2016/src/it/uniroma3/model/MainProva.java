package it.uniroma3.model;




public class MainProva {
 
	public static void main(String[] args) {
		
		FacadeAdmin facade=new FacadeAdmin();
		Amministratore a=facade.login(1L, "prova");
		
		System.out.println("Amministratore:" +a.getNome() );
		

	}

}
