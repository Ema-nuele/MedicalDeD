package it.uniroma3.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
public class Prerequisito {
	
	@Id
	private String nome;
	@Column(nullable=false)
	private String valore;
	@OneToMany( cascade = {CascadeType.PERSIST})
	private List<TipologiaEsame> tipologie;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getValore() {
		return valore;
	}
	public void setValore(String valore) {
		this.valore = valore;
	}
	public List<TipologiaEsame> getTipologie() {
		return this.tipologie;
	}
	public void setTipologie(List<TipologiaEsame> tipologie) {
		this.tipologie = tipologie;
	}
	public Prerequisito(String nome, String valore) {
		super();
		this.nome = nome;
		this.valore = valore;
		this.tipologie=new ArrayList<>();
	}
	
	public void addTipologia(TipologiaEsame t)
	{
		this.tipologie.add(t);
	}
	
	

}
