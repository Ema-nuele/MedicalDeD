package it.uniroma3.model;


import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless(name = "facadeTipologia")
public class FacadeTipologia {

	    @PersistenceContext(unitName = "clinica-unit")
		private EntityManager em;
	    
	    
	    public void aggiungi(TipologiaEsame tipo)
	    {
	    	em.persist(tipo);
	    	
	    }
} 