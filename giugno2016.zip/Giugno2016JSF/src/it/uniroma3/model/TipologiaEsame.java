package it.uniroma3.model;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name ="TipologiaEsame")

// possibile lista che ritorna tutti gli esami
//List<TipologiaEsame> esami= em.createNamedQuery("mostraTipologie").getResultList();

public class TipologiaEsame {
	@Id
	private String nomeTipologia;
	@Column(nullable=false)
	private String descrizione;
	@Column(nullable=false)
	private double costoTipologia;
	@ManyToMany(fetch = FetchType.EAGER)
	private List<Prerequisito> prerequisiti;
	@ManyToMany(fetch = FetchType.EAGER)
	private List<Indicatore> indicatori;
	
	public String getNomeTipologia() {
		return this.nomeTipologia;
	}
	
	public void setNomeTipologia(String nome) {
		this.nomeTipologia = nome;
		
	}
	
	public String getDescrizione() {
		return this.descrizione;
		
	}
	
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	
	public double getCostoTipologia() {
		return this.costoTipologia;
	}
	
	public void setCostoTipologia(double costo) {
		this.costoTipologia = costo;
	}

	public TipologiaEsame(String nomeTipologia, String descrizione, 
			double costoTipologia,List<Prerequisito> p,List<Indicatore> i) {
		this.nomeTipologia = nomeTipologia;
		this.descrizione = descrizione;
		this.costoTipologia = costoTipologia;
		this.prerequisiti = p;
		this.indicatori = i;
	}
	
	


}
