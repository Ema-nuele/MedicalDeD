package it.uniroma3.model;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import it.uniroma3.model.Medico;


@Stateless(name = "facadeMedico")
public class FacadeMedico 
{
    	@PersistenceContext(unitName = "clinica-unit")
    	private EntityManager em;


	public Medico cerca(String nome, String cognome) 
	{
		Query query=em.createQuery("SELECT m FROM Medico m WHERE m.nome=: nome AND m.cognome= :cognome" );
		query.setParameter("nome", nome);
		query.setParameter("cognome", cognome);
		Medico m=(Medico)query.getSingleResult();
		return m;
	}

}
