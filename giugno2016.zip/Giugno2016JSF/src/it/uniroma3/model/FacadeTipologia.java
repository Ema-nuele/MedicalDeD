package it.uniroma3.model;


import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless(name = "facadeTipologia")
public class FacadeTipologia {

	    @PersistenceContext(unitName = "clinica-unit")
		private EntityManager em;
	    
	    
	    public void aggiungi(TipologiaEsame tipo)
	    {
	    	em.persist(tipo);
	    	
	    }
	    
	    @SuppressWarnings("unchecked")
		public List<Prerequisito> ottieniPrerequisiti() {
			Query query = em.createQuery("SELECT t FROM Prerequisito t");
			List<Prerequisito> lista = new ArrayList<>();
			lista = (List<Prerequisito>)query.getResultList();
			return lista;
			
		}
} 