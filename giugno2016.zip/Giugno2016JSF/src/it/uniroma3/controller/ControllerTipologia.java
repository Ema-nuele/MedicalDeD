package it.uniroma3.controller;


import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import it.uniroma3.model.TipologiaEsame;
import it.uniroma3.model.FacadeTipologia;

@ManagedBean(name="controllerTipologia")
@SessionScoped
public class ControllerTipologia
{
	private String nomeTipologia;
	private String descrizione;
	private double costoTipologia;
	private TipologiaEsame tipologia;
	
	@EJB(beanName="facadeTipologia")
	private FacadeTipologia facade;
	
	
	public String vaiAiPrerequisiti()
	{
		tipologia=new TipologiaEsame(this.nomeTipologia,this.descrizione,this.costoTipologia);
		return "inserisciPrerequisiti";
	}
	
	public String aggiungi()
	{
		facade.aggiungi(tipologia);
		return "amministrazione";
	}

	public String annulla()
	{
		this.tipologia=null;
		return"inserisciTipologiaEsame";
	}
	
	public String getNomeTipologia() {
		return this.nomeTipologia;
	}

	public void setNomeTipologia(String nomeTipologia) {
		this.nomeTipologia = nomeTipologia;
	}

	public String getDescrizione() {
		return this.descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public double getCostoTipologia() {
		return this.costoTipologia;
	}

	public void setCostoTipologia(double costoTipologia) {
		this.costoTipologia = costoTipologia;
	}

	public TipologiaEsame getTipologia() {
		return this.tipologia;
	}

	public void setTipologia(TipologiaEsame tipologia) {
		this.tipologia = tipologia;
	}
	
	
	
}
