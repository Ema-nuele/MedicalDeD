package it.uniroma3.controller;


import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import it.uniroma3.model.TipologiaEsame;
import it.uniroma3.model.FacadeTipologia;
import it.uniroma3.model.Indicatore;
import it.uniroma3.model.Prerequisito;

@ManagedBean(name="controllerTipologia")
@SessionScoped
public class ControllerTipologia
{
	private String nomeTipologia;
	private String descrizione;
	private double costoTipologia;
	private TipologiaEsame tipologia;
	private List<Prerequisito> prerequisiti;
	private List<Indicatore> indicatori;
	private Prerequisito p;
	private Indicatore i;
	private String scelta;
	
	public Indicatore getI() {
		return i;
	}

	public void setI(Indicatore i) {
		this.i = i;
	}

	public Prerequisito getP() {
		return p;
	}

	public List<Indicatore> getIndicatori() {
		return indicatori;
	}

	public void setIndicatori(List<Indicatore> indicatori) {
		this.indicatori = indicatori;
	}

	public void setP(Prerequisito p) {
		this.p = p;
	}

	public String getScelta() {
		
		return scelta;
	}

	public void setScelta(String scelta) {
		this.scelta = scelta;
	}

	@EJB(beanName="facadeTipologia")
	private FacadeTipologia facade;
	

	
	public List<Prerequisito> getPrerequisiti() {
		return this.prerequisiti;
	}

	public void setPrerequisiti(List<Prerequisito> prerequisiti) {
		this.prerequisiti = prerequisiti;
	}

	public String vaiAiPrerequisiti()
	{
		prerequisiti = facade.ottieniPrerequisiti();
		indicatori = facade.ottieniIndicatori();
		tipologia=new TipologiaEsame(this.nomeTipologia,this.descrizione,
				this.costoTipologia,this.prerequisiti,this.indicatori);
		return "inserisciPrerequisiti";
	}
	
//	public String aggiungiPrerequisito() {
//		for(Prerequisito p : this.prerequisiti)
//			scelta = p.getNome();
//		return scelta;
//	}
	public String vaiAIndicatori() {
		
		return "inserisciIndicatori";
	}
	
	public String aggiungi()
	{
		facade.aggiungi(tipologia);
		return "amministrazione";
	}

	public String annulla()
	{
		this.tipologia=null;
		return"inserisciTipologiaEsame";
	}
	
	public String getNomeTipologia() {
		return this.nomeTipologia;
	}

	public void setNomeTipologia(String nomeTipologia) {
		this.nomeTipologia = nomeTipologia;
	}

	public String getDescrizione() {
		return this.descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public double getCostoTipologia() {
		return this.costoTipologia;
	}

	public void setCostoTipologia(double costoTipologia) {
		this.costoTipologia = costoTipologia;
	}

	public TipologiaEsame getTipologia() {
		return this.tipologia;
	}

	public void setTipologia(TipologiaEsame tipologia) {
		this.tipologia = tipologia;
	}
	
	
	
}
