package it.uniroma3.controller;

import it.uniroma3.model.Medico;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import it.uniroma3.model.Esame;
import it.uniroma3.model.FacadeMedico;
@ManagedBean(name="controllerMedico")
public class ControllerMedico 
{
	private String nome;
	private String cognome;
	private Medico medico;
	private List<Esame> esami;

	@EJB(beanName="facadeMedico")
	private FacadeMedico facade;


	public String cercaEsami()
	{
		this.medico=this.facade.cerca(this.nome,this.cognome);
		this.esami=this.medico.getEsami();
		return "mostraEsamiMedico";
	}

	public String getNome() 
	{
		return nome;
	}
	public void setNome(String nome) 
	{
		this.nome = nome;
	}
	public String getCognome() 
	{
		return cognome;
	}
	public void setCognome(String cognome) 
	{
		this.cognome = cognome;
	}
	public Medico getMedico() 
	{
		return medico;
	}
	public void setMedico(Medico medico) 
	{
		this.medico = medico;
	}

	public List<Esame> getEsami() 
	{
		return this.esami;
	}

	public void setEsami(List<Esame> esami) 
	{
		this.esami = esami;
	}

}
