package it.uniroma3.controller;

import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import it.uniroma3.model.Esame;
import it.uniroma3.model.FacadeEsame;
import it.uniroma3.model.Medico;
import it.uniroma3.model.Paziente;
import it.uniroma3.model.TipologiaEsame;

@ManagedBean(name="controllerEsame")
@SessionScoped

public class ControllerEsame 
{
	private Paziente paziente;
	private TipologiaEsame tipoEsame;
	private Date dataCreazione;
	private String dataEsame;
	private Medico medico;
	private Esame esame;
	private List<Medico> medici;
	private List<Paziente> pazienti;
	private List<TipologiaEsame> tipologie;
	private String sceltaM;
	private String sceltaT;
	private String sceltaP;
	private String errore;

	@EJB(beanName="facadeEsame")
	private FacadeEsame facade;



	public String getSceltaM() 
	{
		return sceltaM;
	}


	public void setSceltaM(String sceltaM) 
	{
		this.sceltaM = sceltaM;
	}


	public String getSceltaT() 
	{
		return sceltaT;
	}


	public void setSceltaT(String sceltaT) 
	{
		this.sceltaT = sceltaT;
	}


	public String getSceltaP() 
	{
		return sceltaP;
	}


	public void setSceltaP(String sceltaP) 
	{
		this.sceltaP = sceltaP;
	}


	public String getErrore() 
	{
		return errore;
	}


	public void setErrore() 
	{
		errore = "Formato non valido,";
	}


	public List<Medico> getMedici() 
	{
		return medici;
	}


	public void setMedici(List<Medico> medici) 
	{
		this.medici = medici;
	}


	public List<Paziente> getPazienti() 
	{
		return pazienti;
	}


	public void setPazienti(List<Paziente> pazienti) 
	{
		this.pazienti = pazienti;
	}


	public List<TipologiaEsame> getTipologie() 
	{
		return tipologie;
	}


	public void setTipologie(List<TipologiaEsame> tipologie) 
	{
		this.tipologie = tipologie;
	}


	public String creaEsame() 
	{
		this.tipologie = facade.ottieniTipoloige();
		this.medici = facade.ottieniMedici();
		this.pazienti = facade.ottieniPazienti();
		dataCreazione=new Date();
		setDataEsame(dataEsame);
	return "inserisciEsame";
	}

	public String salvaEsame() 
	{
		esame = new Esame(this.paziente,this.tipoEsame,this.dataCreazione,
				this.dataEsame, this.medico);
		facade.aggiungi(esame);
	return "amministrazione";
	}




	public String annulla() 
	{
		this.esame=null;
		return "amministrazione";
	}


	public Paziente getPaziente() 
	{
		return this.paziente;
	}

	public void setPaziente(Paziente paziente) 
	{
		this.paziente = paziente;
	}

	public TipologiaEsame getTipoEsame() 
	{
		return this.tipoEsame;
	}

	public void setTipoEsame(TipologiaEsame tipoEsame)
	{
		this.tipoEsame = tipoEsame;
	}

	public Date getDataCreazione() 
	{
		return this.dataCreazione;
	}

	public void setDataCreazione(Date dataCreazione) 
	{
		this.dataCreazione = dataCreazione;
	}

	public String getDataEsame() 
	{
		return this.dataEsame;
	}

	public void setDataEsame(String dataEsame) 
	{
		this.dataEsame = dataEsame;
	}

	public Medico getMedico() 
	{
		return this.medico;
	}

	public void setMedico(Medico medico) 
	{
		this.medico = medico;
	}


	public Esame getEsame() 
	{
		return esame;

	}


	public void setEsame(Esame esame) 
	{
		this.esame = esame;
	}

	public String compilaEsame()
	{
		for(Medico m : this.medici)
		{
			if(m.getNome().equals(this.sceltaM))
			{
				this.medico=m;
				facade.aggiungiMedicoAEsame(this.esame, this.medico);
				this.sceltaM="";
			}
		}
		for(TipologiaEsame t : this.tipologie)
		{
			if(t.getNomeTipologia().equals(this.sceltaT))
			{
				this.tipoEsame = t;
				facade.aggiungiTipologiaAEsame(this.esame, this.tipoEsame);
				this.sceltaT="";
			}
		}
		for(Paziente p : this.pazienti)
		{
			if(p.getNome().equals(this.sceltaM))
			{
				this.paziente = p;
				facade.aggiungiPazienteAEsame(this.esame, this.paziente);
				this.sceltaT="";
			}
		}

		this.setErrore();
		return "confermaEsame";

	}



	public String cancella() 
	{
		this.esame.setDataCreazione(null);
		this.esame.setDataEsame(null);
		this.esame.setMedico(null);
		this.esame.setPaziente(null);
		this.esame.setTipologia(null);
		this.facade.cancella(this.esame);
	return "amministrazione";
	}


}
