package it.uniroma3.facade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless(name = "adminFacade")

public class AdminFacade {
	
	@PersistenceContext(unitName ="clinica-unit")
	private EntityManager em;
}    
