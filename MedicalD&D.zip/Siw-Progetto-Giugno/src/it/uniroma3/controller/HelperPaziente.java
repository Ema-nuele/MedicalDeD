package it.uniroma3.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// CONTROLLO SUI DATI IMMESSI 
public class HelperPaziente 
{
	public boolean Validate(HttpServletRequest request, HttpServletResponse response)
	{
		boolean corretto=true; 
		String nome,cognome,username,password,indirizzo,indError,nomeError,cognomeError,userError,passError;
		String mail,mailError;
		
		nome=request.getParameter("nome");
		cognome=request.getParameter("cognome");
		username=request.getParameter("username");
		password=request.getParameter("password");
		indirizzo=request.getParameter("indirizzo");
		mail=request.getParameter("email");
		
		if(indirizzo.equals(""))
		{
		corretto=false;
		indError="Indirizzo: Campo Obbligatorio";
		request.setAttribute("indError",indError);
		}
	
		if(mail.equals(""))
		{
		corretto=false;
		mailError="Email: Campo Obbligatorio";
		request.setAttribute("mailError",mailError);
		}
	
				
		if(nome.equals(""))
			{
			corretto=false;
			nomeError="Nome: Campo Obbligatorio";
			request.setAttribute("nomeError",nomeError);
			}
		
		if(cognome.equals(""))
		{
		corretto=false;
		cognomeError="Cognome: Campo Obbligatorio";
		request.setAttribute("cognomeError",cognomeError);
		}
		
		if(username.equals(""))
		{
		corretto=false;
		userError="Username: Campo Obbligatorio";
		request.setAttribute("userError",userError);
		}
		
		if(password.equals(""))
		{
		corretto=false;
		passError="Password: Campo Obbligatorio";
		request.setAttribute("passError",passError);
		}
		
        
	
return corretto;	
	}

}
