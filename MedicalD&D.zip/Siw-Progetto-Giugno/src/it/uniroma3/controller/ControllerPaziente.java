package it.uniroma3.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



/**
 * Servlet implementation class ControllerPaziente
 */
@WebServlet("/controllerPaziente")
public class ControllerPaziente extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerPaziente() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HelperPaziente helper=new HelperPaziente();
		String nextPage="/confermaRegistrazionePaziente.jsp";
		if(helper.Validate(request,response))
		  {
			ActionPaziente action=new ActionPaziente();
			HttpSession session = request.getSession();
			session.setAttribute("paziente", action.Execute(request));
		   }
			else
				nextPage="/registrazionePaziente.jsp";
		  
		nextPage=response.encodeURL(nextPage);
		ServletContext servletContext=getServletContext();
		RequestDispatcher rd = servletContext.getRequestDispatcher(nextPage);
		rd.forward(request, response);
		
	}

}
