package it.uniroma3.helper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelperTipologia {
	
		public boolean Validate(HttpServletRequest request, HttpServletResponse response)
		{
			boolean corretto=true; 
			String nome,descrizione,costo,nomeError,descError,costoError;
			
			
			nome=request.getParameter("nome");
			descrizione=request.getParameter("descrizione");
			costo=request.getParameter("costo");
			
			if(nome.equals(""))
			{
			corretto=false;
			nomeError="Nome: Campo Obbligatorio";
			request.setAttribute("nomeError",nomeError);
			}
		
			if(descrizione.equals(""))
			{
			corretto=false;
			descError="Descrizione: Campo Obbligatorio";
			request.setAttribute("descError",descError);
			}
		
			
			if(costo.equals(""))
			{
			corretto=false;
			costoError="Costo: Campo Obbligatorio";
			request.setAttribute("costoError",costoError);
			}
		
			
			
		return corretto;

}
}
