package it.uniroma3.helper;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// CONTROLLO SUI DATI IMMESSI 
public class HelperEsame
{
	public boolean Validate(HttpServletRequest request, HttpServletResponse response)
	{
		boolean corretto=true; 
		String paziente,medico,dataEsame,tipo,tipoError,pazienteError,medicoError,dataError;
		paziente=request.getParameter("paziente");
		medico=request.getParameter("medico");
		dataEsame=request.getParameter("dataEsame");
		tipo=request.getParameter("tipologiaEsame");
		
				
		if(paziente.equals(""))
			{
			corretto=false;
			pazienteError="Paziente: Campo Obbligatorio";
			request.setAttribute("pazienteError",pazienteError);
			}
		
		if(tipo.equals(""))
		{
		corretto=false;
		tipoError="TipologiaEsame: Campo Obbligatorio";
		request.setAttribute("tipoError",tipoError);
		}
	
		
		
		if(medico.equals(""))
		{
		corretto=false;
		medicoError="Medico: Campo Obbligatorio";
		request.setAttribute("medicoError",medicoError);
		}
		
		if(dataEsame.equals(""))
		{
		corretto=false;
		dataError="DataEsame: Campo Obbligatorio";
		request.setAttribute("dataError",dataError);
		}
		
return corretto;	
	}

}