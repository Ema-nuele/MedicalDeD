package it.uniroma3.controller;
import javax.ejb.*;
import javax.annotation.*;

import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ManagedBean;

import it.uniroma3.model.Amministratore;
import it.uniroma3.model.Facade;

@ManagedBean
@SessionScoped

public class ControllerLogin  {
    
	@EJB(beanName="Facade")
	private Facade facade;
	private Long id;
	private String password;
	private Amministratore amministratore;
	
	
	public Amministratore getAmministratore() {
		return amministratore;
	}
	public void setAmministratore(Amministratore amministratore) {
		this.amministratore = amministratore;
	}


	
	
	
	public Facade getFacade() {
		return facade;
	}
	public void setFacade(Facade facade) {
		this.facade = facade;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public String login(Long id, String password)
	{
		Amministratore a=this.facade.loginAmministratore(id, password);
		if(a!=null)
		      { this.amministratore=a;
		        return "amministrazione";
		      }
	return "login";		
	}
   

	
    /*
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nextPage="/login.jsp";
		Long id=Long.valueOf(request.getParameter("username")).longValue();
		String password=request.getParameter("password");
		if(this.facade.loginAmministratore(id,password,request))
			 nextPage="/amministrazione.jsp";
		nextPage=response.encodeURL(nextPage);
		ServletContext servletContext=getServletContext();
		RequestDispatcher rd = servletContext.getRequestDispatcher(nextPage);
		rd.forward(request, response);
}
*/
}
