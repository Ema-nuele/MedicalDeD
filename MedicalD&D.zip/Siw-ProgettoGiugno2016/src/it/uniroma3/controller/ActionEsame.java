package it.uniroma3.controller;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;


import java.util.Calendar;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import it.uniroma3.model.Facade;
import it.uniroma3.model.Esame;



public class ActionEsame {
	
	public String Execute(HttpServletRequest request, EntityManager em) throws java.text.ParseException
	{
		Esame esame =new Esame();
		Facade facade=new Facade();
		SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyyy");  // formato data da convertire
		Calendar c = Calendar.getInstance();
		
		//esame.setPaziente(Long.valueOf(request.getParameter("paziente")).longValue()); //cast String to Long
		//esame.setMedico(Long.valueOf(request.getParameter("cognome")).longValue());
		//esame.setTipologia(Long.valueOf(request.getParameter("tipologiaEsame")).longValue());
		
		try{
		String data=request.getParameter("dataEsame");
		esame.setDataEsame(format.parse(data)); }
		catch(ParseException e)
		{ e.printStackTrace();}
		
		esame.setDataCreazione(c.getTime());   //prende data istantanea
		
		facade.inserisciEsame(esame,em);
		request.setAttribute("esame",esame);
	return "/EndEsame.jsp";


	}

}
