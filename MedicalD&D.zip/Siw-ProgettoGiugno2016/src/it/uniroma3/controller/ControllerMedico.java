package it.uniroma3.controller;


import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.uniroma3.model.Facade;
import it.uniroma3.model.Medico;
import it.uniroma3.model.Esame;

/**
 * Servlet implementation class ControllerMedico
 */
@WebServlet("/controllerMedico")
public class ControllerMedico extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerMedico() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nome=request.getParameter("nome");
		String cognome=request.getParameter("cognome");
		String nextPage="/MostraEsamiMedico.jsp";
		
		HelperMedico helper=new HelperMedico();
		if(helper.Validate(request,response))
		{
						Facade facade=new Facade();
						Medico m=facade.getMedicoByNome(nome,cognome);
						List<Esame> esami=new ArrayList<>(facade.getEsamiMedico(m));
						//request.setAttribute("esami", esami);
						HttpSession session = request.getSession();
						session.setAttribute("esami", esami);
		}
		
		else nextPage="/esamiMedico.jsp";
		nextPage=response.encodeURL(nextPage);
		ServletContext servletContext=getServletContext();
		RequestDispatcher rd = servletContext.getRequestDispatcher(nextPage);
		rd.forward(request, response);
	}

}
