package it.uniroma3.model;
import java.util.HashMap;
import java.util.Map;
public class Clinica {
	private Map<String,Utente> amministratori;
	private Map<String,Utente> pazienti;
	
	public Clinica() {
		this.pazienti = new HashMap<>();
		this.amministratori = new HashMap<>();
		
	}

	public Map<String, Utente> getAmministratori() {
		return amministratori;
	}

	public void setAmministratori(Map<String, Utente> amministratori) {
		this.amministratori = amministratori;
	}

	public Map<String, Utente> getPazienti() {
		return pazienti;
	}

	public void setPazienti(Map<String, Utente> pazienti) {
		this.pazienti = pazienti;
	}
	
	

}
