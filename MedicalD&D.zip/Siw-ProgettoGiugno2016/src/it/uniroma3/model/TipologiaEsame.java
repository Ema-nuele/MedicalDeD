package it.uniroma3.model;

import java.util.Map;

public class TipologiaEsame {
	private String nomeE;
	private long codiceE;
	private String descrizioneE;
	private int costoE;
	private Map<String,String> prerequisiti;
	
	public TipologiaEsame(){}
	
	public String getNome() {
		return this.nomeE;
	}
	
	public void setNome(String nome) {
		this.nomeE = nome;
		
	}
	
	public long getCodice() {
		return this.codiceE;
	}
	
	public void setCodice(long codice) {
		this.codiceE = codice;
	}
	
	public String getDescrizione() {
		return this.descrizioneE;
		
	}
	
	public void setDescrizione(String descrizione) {
		this.descrizioneE = descrizione;
	}
	
	public int getCosto() {
		return this.costoE;
	}
	
	public void setCosto(int costo) {
		this.costoE = costo;
	}
	public Map<String,String> getPrerequisiti() {
		return this.prerequisiti;
	}
	public void setPrerequisiti(Map<String,String> prerequisiti) {
		this.prerequisiti = prerequisiti;
	}
}
