package it.uniroma3.model;

public class Main {

	public static void main(String args[])  {
		Clinica clinica = new Clinica();
		
		
	}
}
