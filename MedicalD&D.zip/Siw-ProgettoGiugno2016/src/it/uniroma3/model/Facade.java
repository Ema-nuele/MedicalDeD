package it.uniroma3.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


public class Facade {
	
	// Inserimenti 
	public void inserisciPaziente(Paziente paziente)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("clinica-unit");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
        tx.begin();
		em.persist(paziente); 
        tx.commit();
		em.close();
		emf.close();
	}
	
	public void inserisciEsame(Esame e, EntityManager em)
	{
		EntityTransaction tx = em.getTransaction();
        tx.begin();
		em.persist(e);
		tx.commit();
	}
	
	// Query
	
	public boolean loginAmministratore(Long id,String password, EntityManager em, HttpServletRequest request)
	{
		Query query = em.createQuery("SELECT a FROM Amministratore a WHERE a.id = :id");
		query.setParameter("id",id);
		if(query.getSingleResult()!=null)
		{            Amministratore a=(Amministratore) query.getSingleResult();
		             if(a.getPassword().equals(password))
		             {  	 HttpSession session = request.getSession();
		 			         session.setAttribute("amministratore",a);
				             return true;
		             }
		}            
		return false;
	}
	
	
	public void logout(HttpServletRequest request)
	{
		
	}
	
	public List<TipologiaEsame> getTipologie(EntityManager em)
	{
		Query query = em.createQuery("SELECT t FROM TipologiaEsame t");
		return (List<TipologiaEsame>) query.getResultList();
	}
	
	//Query UC5
	
	public List<Esame> getEsamiMedico(Long id, EntityManager em)
	{
		Query query = em.createQuery("SELECT e FROM Esame e WHERE e.medico = :medico");
		query.setParameter("medico",id);
		return (List<Esame>) query.getResultList();
	}

}
