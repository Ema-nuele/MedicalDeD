package it.uniroma3.model;

import java.util.List;

public class Paziente {
	private String indirizzo;
	private String email;
	private String ruolo;
	//private List<Esame> esami;
	// private List<Ordine> listaOrdini; Servirà conoscere gli ordini??

	public Paziente() {
		this.ruolo = "user";

	}

	public Paziente(String indirizzo, String email) {
		this.ruolo = "user";
		this.indirizzo = indirizzo;
		this.email = email;
	}

	public String getIndirizzo() {
		return this.indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRuolo() {
		return this.ruolo;
	}

	public void setRuolo(String ruolo) {
		this.ruolo = ruolo;
	}

}
