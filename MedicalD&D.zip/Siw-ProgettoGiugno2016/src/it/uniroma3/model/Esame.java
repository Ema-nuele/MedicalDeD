package it.uniroma3.model;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Esame {
	private long id;
	private Utente paziente;
	private Date dataPrenotazione;
	private Date dataEsame;
	private Medico m;
	private Map<String,String> risultato;
	

	public Esame(Utente paziente, Date dataPrenotazione, Date dataEsame, Medico m) {
		this.paziente = paziente;
		this.dataPrenotazione = dataPrenotazione;
		this.dataEsame = dataEsame;
		this.m = m;
		this.risultato = new HashMap<>();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Utente getPaziente() {
		return paziente;
	}

	public void setUtente(Utente paziente) {
		this.paziente = paziente;
	}

	public Date getDataPrenotazione() {
		return this.dataPrenotazione;
	}

	public Date getDataEsame() {
		return dataEsame;
	}

	public void setDataEsame(Date dataEsame) {
		this.dataEsame = dataEsame;
	}

	public void setDataPrenotazione(Date data) {
		this.dataPrenotazione = data;
	}

	public String getNomeMedico() {
		return m.getNome();
	}
	public void setMedico(Medico m) {
		this.m = m;
	}


	public Map<String, String> getRisultato() {
		return this.risultato;
	}

	public void setRisultato(Map<String, String> risultato) {
		this.risultato = risultato;
	}
	
		
	
	
}
