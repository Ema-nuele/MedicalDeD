package it.uniroma3.model;

import java.util.Date;
import java.util.List;
import javax.persistence.*;

@Entity
public class Esame {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@OneToOne
	private Paziente paziente;
	@Temporal (TemporalType.TIMESTAMP)
    private Date dataCreazione;
	@Temporal (TemporalType.DATE)
    private Date dataPrenotazione;
	@Column(nullable=false)
	private Date dataEsame;
	@OneToOne
	private Medico medico;
	@OneToMany
	private List<Risultato> risultati;
	

	public Paziente getPaziente() {
		return paziente;
	}

	public void setPaziente(Paziente paziente) {
		this.paziente = paziente;
	}

	public Date getDataPrenotazione() {
		return this.dataPrenotazione;
	}

	public Date getDataEsame() {
		return dataEsame;
	}

	public void setDataEsame(Date dataEsame) {
		this.dataEsame = dataEsame;
	}

	public void setDataPrenotazione(Date data) {
		this.dataPrenotazione = data;
	}

	public String getNomeMedico() {
		return getNomeMedico();
	}

	
   public Medico getM() {
		return medico;
	}

	public void setM(Medico m) {
		this.medico = m;
	}	
	
}
